from django.contrib import admin
from .models import Channel, Message # تأكد من استيراد الموديلز الخاصة بك هنا

# تسجيل الموديلز لتظهر في الـ Admin Dashboard
admin.site.register(Channel)
admin.site.register(Message)